using System;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace InitDotNet.Entities;

public class User : IdentityUser
{

    public required string ConfirmationChange { get; set; }

}
