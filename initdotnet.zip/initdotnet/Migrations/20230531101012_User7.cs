﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace initdotnet.Migrations
{
    /// <inheritdoc />
    public partial class User7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
