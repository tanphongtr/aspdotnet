using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.Extensions.Caching.Distributed;
using System.Text;

namespace InitDotNet;

public class TestModel
{
    string Txt;
}


[ApiController]
[Route("api/[controller]")]
public class TestController : Controller // use Controller for View(), use ControllerBase for API view
{

    private readonly ILogger _logger;

    private readonly IDistributedCache _cache;

    public TestController(ILogger<TestController> logger, IDistributedCache cache)
    {
        _logger = logger;
        _cache = cache;
    }

    [HttpGet("test")]
    // [Cached(600)]
    public async Task<IActionResult> Index([FromForm] TestModel txt)
    {
        var foo = await _cache.GetStringAsync("foo");
        var options = new DistributedCacheEntryOptions()
            .SetAbsoluteExpiration(DateTime.Now.AddSeconds(20))
            .SetSlidingExpiration(TimeSpan.FromSeconds(10));

        var redisCustomerList = Encoding.UTF8.GetBytes(DateTime.Now.ToString());
        await _cache.SetAsync("foo", redisCustomerList, options);

        // add 1 value to redis
        await _cache.SetStringAsync("foo2", "bar");

        // add 1 value type int to redis


        Console.WriteLine(foo);
        // return View();
        Response.Headers.Add("Cache-Control", "max-age=604800");
        return Ok("test");
    }

    [HttpGet("test-cache")]
    [Cached(600)]
    public IActionResult TestCache()
    {
        Console.WriteLine("TestCache start controller");
        return new ContentResult
        {
            Content = DateTime.Now.ToString(),
            ContentType = "text/html",
            StatusCode = 200
        };
    }

    [HttpGet("test2")]
    [OutputCache(Duration = 10)]
    public IActionResult Test()
    {
        return View();
    }

    [HttpGet("test3")]
    public async Task<IActionResult> Test3()
    {
        var foo = await _cache.GetStringAsync("sss");
        Console.WriteLine("+" + foo);
        return Ok("");
    }

    [Route("res-cache")]
    [HttpGet]
    [ResponseCache(VaryByHeader = "User-Agent", Duration = 30)]
    public ContentResult GetTime() => Content(DateTime.Now.Millisecond.ToString());

    [HttpPost("upload")]
    public async Task<IActionResult> UploadFile([FromForm] List<IFormFile> files)
    {
        long size = files.Sum(f => f.Length);
        string[] permittedExtensions = { ".txt", ".pdf", ".mp4", ".jpg" };

        foreach (var formFile in files)
        {
            if (formFile.Length > 0)
            {
                var ext = Path.GetExtension(formFile.FileName).ToLowerInvariant();
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", Guid.NewGuid().ToString("N") + ext);

                // GUID for file name
                // var fileName = Guid.NewGuid().ToString() + ext;

                // check file exist by FileStream
                if (System.IO.File.Exists(filePath))
                {
                    return BadRequest(new { message = "File already exist" });
                }

                if (string.IsNullOrEmpty(ext) || !permittedExtensions.Contains(ext))
                {
                    return BadRequest(new { message = "File extension is not permitted" });
                }

                using var stream = new FileStream(filePath, FileMode.Create);
                await formFile.CopyToAsync(stream);
            }
        }

        return Ok(new { count = files.Count, size });
    }

}
