using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using InitDotNet.Data;
using InitDotNet.Entities;
using Microsoft.AspNetCore.Identity;

var builder = WebApplication.CreateBuilder(args);

// limit upload file size
builder.Services.Configure<FormOptions>(options =>
{
    options.MultipartBodyLengthLimit = 104857600; // 100MB
});

// Db context
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlite(connectionString));


// Identity
builder.Services.AddDefaultIdentity<User>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>();

// Using Cors
builder.Services.AddCors();

builder.Services.AddControllers();

builder.Services.AddRazorPages(); // using IActionResult return View() in Controller (using Microsoft.AspNetCore.Mvc;)

builder.Services.AddStackExchangeRedisCache((options) => // DI: IDistributedCache
{
    options.Configuration = "localhost:6379";
    options.InstanceName = "SampleInstance_"; // set prefix key
});

builder.Services.AddRateLimiter(_ => _
    .AddFixedWindowLimiter(policyName: "fixed", options =>
    {
        options.PermitLimit = 4;
        options.Window = TimeSpan.FromSeconds(12);
        options.QueueProcessingOrder = QueueProcessingOrder.OldestFirst;
        options.QueueLimit = 2;
    }));

builder.Services.AddDistributedMemoryCache();

builder.Services.AddResponseCaching();

var app = builder.Build();

app.UseCors(_ => _.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());

app.MapGet("/", () => Results.Json(new { Server = "185.215.166.87", Application = "api" }));

// upload file
app.MapPost("/upload", async (IFormFile file) =>
{
    var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", file.FileName);
    using var stream = new FileStream(path, FileMode.Create);
    
    await file.CopyToAsync(stream);
    return Results.Json(new { file.FileName, file.Length });
});

app.MapControllers();

// app.UseWelcomePage();

app.UseResponseCaching();

app.UseRateLimiter();

app.Run();
