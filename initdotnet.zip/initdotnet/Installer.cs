using Microsoft.AspNetCore.Mvc;
using StackExchange.Redis;
using Microsoft.Extensions.Caching.Distributed;
using System.Text;
using Microsoft.AspNetCore.Mvc.Filters;

namespace InitDotNet;

public class TestInstaller // use Controller for View(), use ControllerBase for API view
{


}

public class CachedAttribute : Attribute, IAsyncActionFilter
{
    private readonly int _TimeToLive;

    public CachedAttribute(int TimeToLive)
    {
        _TimeToLive = TimeToLive;
    }

    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {

        // var cacheKey = context.HttpContext.Request.Path.ToString();
        var cacheKey = "foo";
        var cachedResponse = await context.HttpContext.RequestServices.GetRequiredService<IDistributedCache>().GetStringAsync(cacheKey);

        if (!string.IsNullOrEmpty(cachedResponse))
        {
            context.Result = new ContentResult
            {
                Content = cachedResponse,
                ContentType = "text/html",
                StatusCode = 200
            };
            return;
        }

        var executedContext = await next();

        if (executedContext.Result is ContentResult result)
        {
            await context.HttpContext.RequestServices.GetRequiredService<IDistributedCache>().SetStringAsync(cacheKey, result.Content, new DistributedCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(_TimeToLive)
            });
        }

    }

}

